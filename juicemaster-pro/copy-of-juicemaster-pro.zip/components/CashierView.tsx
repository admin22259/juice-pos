import React, { useState } from 'react';
import { MenuItem, CartItem } from '../types';
import { Plus, Minus, Trash2, Printer, ShoppingBag, Coffee, UtensilsCrossed, Candy, IceCream, Zap, Salad, Cookie } from 'lucide-react';
import { MOCK_MENU_ITEMS, GOOGLE_SHEET_URL } from '../constants';

interface CashierViewProps {
  cart: CartItem[];
  onAddToCart: (item: MenuItem) => void;
  onRemoveFromCart: (itemId: string) => void;
  onUpdateQuantity: (itemId: string, delta: number) => void;
  onCheckout: (paymentMethod: 'Cash' | 'Card' | 'Online') => void;
  onClearCart: () => void;
}

export const CashierView: React.FC<CashierViewProps> = ({
  cart,
  onAddToCart,
  onRemoveFromCart,
  onUpdateQuantity,
  onCheckout,
  onClearCart
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('الكل');

  const categories = [
    { id: 'الكل', label: 'الكل', icon: ShoppingBag },
    { id: 'عصائر', label: 'عصائر', icon: Coffee },
    { id: 'كوكتيل', label: 'كوكتيل', icon: UtensilsCrossed },
    { id: 'ميلك شيك', label: 'ميلك شيك', icon: Coffee },
    { id: 'ايس كريم', label: 'ايس كريم', icon: IceCream },
    { id: 'وافل وكريب', label: 'وافل وكريب', icon: Cookie },
    { id: 'مشروبات طاقة', label: 'مشروبات طاقة', icon: Zap },
    { id: 'سلطة فواكه', label: 'سلطة فواكه', icon: Salad },
  ];

  const filteredItems = activeCategory === 'الكل' 
    ? MOCK_MENU_ITEMS 
    : MOCK_MENU_ITEMS.filter(item => item.category === activeCategory);

  // Helper to format OMR currency
  const formatCurrency = (val: number) => {
    return val.toFixed(3) + ' ر.ع.';
  };

  const totalAmount = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handlePrintAndSave = () => {
    // 1. Prepare Data
    const invoiceId = Math.random().toString(36).substr(2, 9).toUpperCase();
    const date = new Date().toLocaleDateString('en-GB');
    const time = new Date().toLocaleTimeString('en-GB');
    const itemsStr = cart.map(i => `${i.name} (${i.quantity})`).join(' + ');
    const total = totalAmount.toFixed(3);
    
    // 2. CSV Content with BOM for Arabic support
    const csvContent = `\uFEFFInvoice ID,Date,Time,Items,Total,Payment Method\n${invoiceId},${date},${time},"${itemsStr}",${total},Cash/Print`;
    
    // 3. Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Invoice_${date.replace(/\//g, '-')}_${invoiceId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // 4. Open Google Sheet
    window.open(GOOGLE_SHEET_URL, "_blank");
    
    // 5. Native Print
    window.print();
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-8rem)]">
      {/* Menu Section (Left Side) */}
      <div className="lg:w-2/3 flex flex-col gap-6">
        {/* Categories */}
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium whitespace-nowrap transition-all ${
                  isActive 
                    ? 'bg-orange-600 text-white shadow-lg shadow-orange-500/30' 
                    : 'bg-white text-gray-600 border border-gray-100 hover:bg-orange-50'
                }`}
              >
                <Icon size={18} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Products Grid */}
        <div className="flex-1 overflow-y-auto pr-2">
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onAddToCart(item)}
                className={`border hover:border-orange-300 p-4 rounded-2xl flex flex-col gap-3 transition-all hover:shadow-md group text-right ${item.color.replace('text-', 'bg-').replace('100', '50/30')}`}
              >
                <div className={`w-full aspect-square rounded-xl ${item.color} flex items-center justify-center text-3xl font-bold mb-2 group-hover:scale-105 transition-transform shadow-sm`}>
                  {item.name.charAt(0)}
                </div>
                <div className="flex-1 w-full">
                  <h4 className="font-bold text-gray-800 line-clamp-2 text-sm h-10">{item.name}</h4>
                  <p className="text-xs text-gray-500 mt-1">{item.category}</p>
                </div>
                <div className="flex items-center justify-between w-full mt-2">
                  <span className="font-bold text-orange-700 text-lg">{formatCurrency(item.price)}</span>
                  <div className="bg-white/80 p-2 rounded-lg group-hover:bg-orange-500 group-hover:text-white transition-colors shadow-sm">
                    <Plus size={16} />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cart Section (Right Side) */}
      <div className="lg:w-1/3 bg-white rounded-2xl shadow-sm border border-gray-100 flex flex-col h-full overflow-hidden">
        <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50">
          <h3 className="font-bold text-lg text-gray-800 flex items-center gap-2">
            <ShoppingBag className="text-orange-500" />
            سلة المشتريات
          </h3>
          <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-xs font-bold">
            {cart.length} أصناف
          </span>
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-4">
              <ShoppingBag size={48} className="opacity-20" />
              <p>السلة فارغة، اختر منتجات للبدء</p>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.id} className="flex items-center gap-3 p-3 border border-gray-100 rounded-xl hover:border-orange-100 transition-colors">
                <div className={`w-12 h-12 rounded-lg flex-shrink-0 flex items-center justify-center font-bold ${item.color}`}>
                  {item.name.charAt(0)}
                </div>
                
                <div className="flex-1">
                  <h4 className="font-bold text-gray-800 text-sm line-clamp-1">{item.name}</h4>
                  <p className="text-orange-600 text-xs font-bold">{formatCurrency(item.price * item.quantity)}</p>
                </div>

                <div className="flex items-center gap-3 bg-gray-50 rounded-lg p-1">
                  <button 
                    onClick={() => onUpdateQuantity(item.id, -1)}
                    className="w-7 h-7 flex items-center justify-center bg-white rounded shadow-sm hover:text-red-500 disabled:opacity-50"
                  >
                    <Minus size={14} />
                  </button>
                  <span className="font-bold w-4 text-center text-sm">{item.quantity}</span>
                  <button 
                    onClick={() => onUpdateQuantity(item.id, 1)}
                    className="w-7 h-7 flex items-center justify-center bg-white rounded shadow-sm hover:text-green-500"
                  >
                    <Plus size={14} />
                  </button>
                </div>

                <button 
                  onClick={() => onRemoveFromCart(item.id)}
                  className="text-gray-400 hover:text-red-500 p-1"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-5 border-t border-gray-100 bg-gray-50 space-y-4">
          <div className="flex items-center justify-between text-lg">
            <span className="text-gray-600">الإجمالي:</span>
            <span className="font-bold text-2xl text-gray-900">{formatCurrency(totalAmount)}</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
             <button 
               onClick={onClearCart}
               disabled={cart.length === 0}
               className="flex items-center justify-center gap-2 px-4 py-3 border border-gray-300 rounded-xl text-gray-600 font-medium hover:bg-white hover:border-red-200 hover:text-red-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
             >
               <Trash2 size={18} />
               <span>إلغاء</span>
             </button>
             <button 
               disabled={cart.length === 0}
               onClick={handlePrintAndSave}
               className="flex items-center justify-center gap-2 px-4 py-3 bg-gray-800 text-white rounded-xl font-medium hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
             >
               <Printer size={18} />
               <span>طباعة وحفظ</span>
             </button>
          </div>

          <button 
            onClick={() => onCheckout('Cash')}
            disabled={cart.length === 0}
            className="w-full py-4 bg-orange-600 text-white rounded-xl font-bold text-lg hover:bg-orange-700 shadow-lg shadow-orange-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
          >
            <span>إتمام البيع (كاش)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
